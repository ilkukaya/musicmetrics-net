"use client";

import Link from "next/link";
import { useMemo, useState } from "react";

type SearchItem = {
  title: string;
  subtitle: string;
  href: string;
};

export function SearchFilter({ items }: { items: SearchItem[] }) {
  const [query, setQuery] = useState("");

  const filtered = useMemo(() => {
    if (!query.trim()) return items.slice(0, 6);
    const normalized = query.toLowerCase();
    return items
      .filter((item) => `${item.title} ${item.subtitle}`.toLowerCase().includes(normalized))
      .slice(0, 8);
  }, [items, query]);

  return (
    <div className="rounded-3xl border border-slate-200 bg-white p-6 shadow-soft">
      <label htmlFor="site-search" className="text-sm font-semibold text-ink">
        Search charts, artists, tracks, and countries
      </label>
      <input
        id="site-search"
        value={query}
        onChange={(event) => setQuery(event.target.value)}
        placeholder="Try Taylor Swift, Turkey, or weekly charts"
        className="mt-3 w-full rounded-xl border border-slate-300 px-4 py-3 text-sm text-ink outline-none ring-0 placeholder:text-slate-400 focus:border-accent"
      />
      <div className="mt-4 grid gap-3">
        {filtered.map((item) => (
          <Link key={item.href} href={item.href} className="rounded-2xl border border-slate-200 p-4 transition hover:border-accent hover:bg-slate-50">
            <p className="font-medium text-ink">{item.title}</p>
            <p className="mt-1 text-sm text-slate-600">{item.subtitle}</p>
          </Link>
        ))}
        {!filtered.length && <p className="text-sm text-slate-500">No matches yet. Try another keyword.</p>}
      </div>
    </div>
  );
}
