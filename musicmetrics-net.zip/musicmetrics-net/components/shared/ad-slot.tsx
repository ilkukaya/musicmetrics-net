export function AdSlot({ label }: { label: string }) {
  return (
    <div className="rounded-2xl border border-dashed border-slate-300 bg-white p-6 text-sm text-slate-500 shadow-soft">
      Reserved {label} placement for future display ads or sponsorship modules.
    </div>
  );
}
