import Link from "next/link";

export function Footer() {
  return (
    <footer className="mt-20 border-t border-slate-200 bg-panel">
      <div className="mx-auto grid max-w-content gap-8 px-6 py-10 md:grid-cols-3">
        <div>
          <p className="text-lg font-semibold text-ink">MusicMetrics</p>
          <p className="mt-2 text-sm leading-6 text-slate-600">
            A cleaner global music analytics product built for discoverability, trust, and future monetization.
          </p>
        </div>
        <div>
          <p className="text-sm font-semibold text-ink">Explore</p>
          <div className="mt-3 grid gap-2 text-sm text-slate-600">
            <Link href="/charts">Charts</Link>
            <Link href="/artists">Artists</Link>
            <Link href="/tracks">Tracks</Link>
            <Link href="/countries">Countries</Link>
            <Link href="/insights">Insights</Link>
          </div>
        </div>
        <div>
          <p className="text-sm font-semibold text-ink">Legal</p>
          <div className="mt-3 grid gap-2 text-sm text-slate-600">
            <Link href="/about">About</Link>
            <Link href="/contact">Contact</Link>
            <Link href="/privacy">Privacy</Link>
            <Link href="/terms">Terms</Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
