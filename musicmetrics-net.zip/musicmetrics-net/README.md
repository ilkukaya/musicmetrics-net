# MusicMetrics

MusicMetrics is a global English-language music analytics MVP built for Netlify and designed to evolve into a chart, artist, track, country, and insights platform.

## Stack

- Next.js 14 App Router
- TypeScript
- Tailwind CSS
- Static-first architecture
- Netlify-ready deployment

## Included routes

- /
- /charts
- /artists
- /tracks
- /countries
- /insights
- /about
- /contact
- /privacy
- /terms
- /charts/[slug]
- /artists/[slug]
- /tracks/[slug]
- /countries/[slug]
- /insights/[slug]

## Local development

```bash
npm install
npm run dev
```

## Netlify

This repository includes `netlify.toml`. After pushing the files to GitHub, Netlify should pick up the repository and build with:

- `npm run build`

## Phase 2 direction

- Spotify API ingestion
- YouTube API ingestion
- Scheduled refresh jobs
- Database layer for scale
- Newsletter integration
- Analytics and ad stack
- Richer editorial and affiliate content
