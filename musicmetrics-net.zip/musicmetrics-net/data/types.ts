export type Chart = {
  slug: string;
  title: string;
  description: string;
  platform: "Spotify" | "YouTube" | "Cross-platform";
  cadence: string;
  market: string;
  updatedAt: string;
  topEntries: string[];
};

export type Artist = {
  slug: string;
  name: string;
  country: string;
  monthlyListeners: string;
  momentum: string;
  summary: string;
  genres: string[];
};

export type Track = {
  slug: string;
  title: string;
  artist: string;
  releaseDate: string;
  trend: string;
  summary: string;
  markets: string[];
};

export type Country = {
  slug: string;
  name: string;
  insight: string;
  leadingPlatforms: string[];
  standoutGenres: string[];
};

export type Insight = {
  slug: string;
  title: string;
  excerpt: string;
  category: string;
  readTime: string;
  publishedAt: string;
  bullets: string[];
};
