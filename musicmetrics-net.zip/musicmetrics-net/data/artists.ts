import type { Artist } from "@/data/types";

export const artists: Artist[] = [
  {
    slug: "taylor-swift",
    name: "Taylor Swift",
    country: "United States",
    monthlyListeners: "103.4M",
    momentum: "+4.8% WoW",
    summary: "A benchmark artist for catalog depth, release-day conversion, and cross-market retention.",
    genres: ["Pop", "Singer-Songwriter"]
  },
  {
    slug: "bad-bunny",
    name: "Bad Bunny",
    country: "Puerto Rico",
    monthlyListeners: "88.7M",
    momentum: "+6.1% WoW",
    summary: "One of the strongest global Latin streaming forces with durable performance across video and audio.",
    genres: ["Latin", "Reggaeton"]
  },
  {
    slug: "mabel-matiz",
    name: "Mabel Matiz",
    country: "Turkey",
    monthlyListeners: "7.1M",
    momentum: "+9.3% WoW",
    summary: "A leading Turkish pop name with high cultural resonance and strong local chart conversion.",
    genres: ["Turkish Pop", "Alternative Pop"]
  }
];
