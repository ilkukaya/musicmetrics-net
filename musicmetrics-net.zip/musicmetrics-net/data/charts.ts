import type { Chart } from "@/data/types";

export const charts: Chart[] = [
  {
    slug: "global-spotify-weekly",
    title: "Global Spotify Weekly Leaders",
    description: "A clean snapshot of the artists and songs dominating weekly attention across major markets.",
    platform: "Spotify",
    cadence: "Weekly",
    market: "Global",
    updatedAt: "2026-03-06",
    topEntries: ["The Weeknd", "Taylor Swift", "Bad Bunny", "Billie Eilish"]
  },
  {
    slug: "youtube-global-fastest-risers",
    title: "YouTube Global Fastest Risers",
    description: "Videos and artists gaining the most visibility through recent view acceleration.",
    platform: "YouTube",
    cadence: "Daily",
    market: "Global",
    updatedAt: "2026-03-06",
    topEntries: ["Karol G", "BTS", "Travis Scott", "Dua Lipa"]
  },
  {
    slug: "turkey-crossover-momentum",
    title: "Turkey Crossover Momentum",
    description: "Tracks breaking across both streaming and video platforms with strong local lift.",
    platform: "Cross-platform",
    cadence: "Daily",
    market: "Turkey",
    updatedAt: "2026-03-06",
    topEntries: ["Semicenk", "Mabel Matiz", "Reynmen", "Simge"]
  }
];
