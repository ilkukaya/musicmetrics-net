import type { Country } from "@/data/types";

export const countries: Country[] = [
  {
    slug: "united-states",
    name: "United States",
    insight: "The deepest commercial market with strong catalog behavior and rapid playlist-driven breakouts.",
    leadingPlatforms: ["Spotify", "YouTube", "Apple Music"],
    standoutGenres: ["Pop", "Hip-Hop", "Country"]
  },
  {
    slug: "turkey",
    name: "Turkey",
    insight: "A high-engagement market where local stars and emotionally resonant repertoire convert strongly.",
    leadingPlatforms: ["YouTube", "Spotify"],
    standoutGenres: ["Turkish Pop", "Arabesk Pop", "Rap"]
  },
  {
    slug: "brazil",
    name: "Brazil",
    insight: "A velocity market where video, fandom activity, and local genre strength combine into rapid movement.",
    leadingPlatforms: ["YouTube", "Spotify"],
    standoutGenres: ["Funk Carioca", "Sertanejo", "Pop"]
  }
];
