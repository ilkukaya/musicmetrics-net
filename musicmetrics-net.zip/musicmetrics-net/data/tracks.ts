import type { Track } from "@/data/types";

export const tracks: Track[] = [
  {
    slug: "blinding-lights",
    title: "Blinding Lights",
    artist: "The Weeknd",
    releaseDate: "2019-11-29",
    trend: "Stable evergreen",
    summary: "A reference track for long-tail retention and repeated global rediscovery.",
    markets: ["United States", "United Kingdom", "Germany", "Brazil"]
  },
  {
    slug: "espresso",
    title: "Espresso",
    artist: "Sabrina Carpenter",
    releaseDate: "2024-04-11",
    trend: "High recurrency",
    summary: "Fast awareness growth paired with strong short-form platform spillover.",
    markets: ["United States", "Canada", "Australia", "Philippines"]
  },
  {
    slug: "fark-ettim",
    title: "Fark Ettim",
    artist: "Semicenk",
    releaseDate: "2025-09-14",
    trend: "Local breakout",
    summary: "A local-market mover with strong replay signals and sustained social traction.",
    markets: ["Turkey", "Germany", "Netherlands"]
  }
];
