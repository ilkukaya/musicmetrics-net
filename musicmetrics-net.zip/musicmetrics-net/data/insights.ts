import type { Insight } from "@/data/types";

export const insights: Insight[] = [
  {
    slug: "how-fast-risers-are-detected",
    title: "How Fast Risers Can Be Detected Before the Mainstream Peak",
    excerpt: "A framework for spotting track acceleration before headline chart coverage catches up.",
    category: "Methodology",
    readTime: "5 min read",
    publishedAt: "2026-03-06",
    bullets: [
      "Measure rate-of-change, not only absolute totals.",
      "Track cross-platform confirmation between audio and video.",
      "Watch market concentration before global spread begins."
    ]
  },
  {
    slug: "why-country-pages-matter",
    title: "Why Country-Level Pages Matter for Music Discovery SEO",
    excerpt: "Country pages capture high-intent queries and create stronger internal linking between artists, tracks, and charts.",
    category: "SEO",
    readTime: "4 min read",
    publishedAt: "2026-03-06",
    bullets: [
      "They answer real search intent around local charts and trends.",
      "They improve crawl structure for artist and track clusters.",
      "They create monetization surface for editorial and affiliate layers."
    ]
  },
  {
    slug: "future-affiliate-zones",
    title: "Where Affiliate Content Fits Inside a Music Data Product",
    excerpt: "A practical view of how gear, creator tools, and listening hardware can fit without ruining trust.",
    category: "Monetization",
    readTime: "6 min read",
    publishedAt: "2026-03-06",
    bullets: [
      "Keep affiliate pages editorial and research-driven.",
      "Separate commercial intent from core chart navigation.",
      "Use trusted comparison formats instead of aggressive placements."
    ]
  }
];
