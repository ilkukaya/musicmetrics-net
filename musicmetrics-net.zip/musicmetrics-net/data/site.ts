export const siteConfig = {
  name: "MusicMetrics",
  domain: "https://musicmetrics.net",
  description:
    "A global music analytics platform designed for chart watchers, artist teams, indie labels, and fans who care about momentum, reach, and cross-platform performance.",
  nav: [
    { href: "/charts", label: "Charts" },
    { href: "/artists", label: "Artists" },
    { href: "/tracks", label: "Tracks" },
    { href: "/countries", label: "Countries" },
    { href: "/insights", label: "Insights" }
  ]
};
