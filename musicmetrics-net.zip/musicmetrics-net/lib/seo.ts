import type { Metadata } from "next";
import { siteConfig } from "@/data/site";

export const absoluteUrl = (path: string) => `${siteConfig.domain}${path}`;

export const buildMetadata = ({
  title,
  description,
  path
}: {
  title: string;
  description: string;
  path: string;
}): Metadata => ({
  title,
  description,
  metadataBase: new URL(siteConfig.domain),
  alternates: {
    canonical: path
  },
  openGraph: {
    title,
    description,
    url: absoluteUrl(path),
    siteName: siteConfig.name,
    type: "website"
  },
  twitter: {
    card: "summary_large_image",
    title,
    description
  }
});
