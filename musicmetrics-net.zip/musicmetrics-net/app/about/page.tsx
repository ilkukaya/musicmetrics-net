import { PageIntro } from "@/components/shared/page-intro";
import { buildMetadata } from "@/lib/seo";

export const metadata = buildMetadata({
  title: "About",
  description: "About MusicMetrics and the product vision behind the platform.",
  path: "/about"
});

export default function AboutPage() {
  return (
    <>
      <PageIntro title="About MusicMetrics" description="A clean, global-first music analytics product designed to grow into a trusted destination for music performance intelligence." />
      <section className="mx-auto max-w-content px-6 py-16">
        <div className="max-w-3xl rounded-3xl border border-slate-200 bg-white p-8 shadow-soft">
          <p className="leading-8 text-slate-600">
            MusicMetrics starts as a static-first MVP focused on search visibility, usability, and strong information architecture. The long-term plan is to combine structured music data, country-level exploration, and editorial context in a way that feels significantly more usable than legacy chart sites.
          </p>
        </div>
      </section>
    </>
  );
}
