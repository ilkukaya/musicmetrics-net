import { PageIntro } from "@/components/shared/page-intro";
import { buildMetadata } from "@/lib/seo";

export const metadata = buildMetadata({
  title: "Contact",
  description: "Contact page placeholder for future brand and partnership inquiries.",
  path: "/contact"
});

export default function ContactPage() {
  return (
    <>
      <PageIntro title="Contact" description="A placeholder contact page for future business inquiries, partnerships, and editorial communication." />
      <section className="mx-auto max-w-content px-6 py-16">
        <div className="max-w-2xl rounded-3xl border border-slate-200 bg-white p-8 shadow-soft">
          <p className="leading-8 text-slate-600">For the MVP, contact infrastructure is intentionally simple. In the next phase, this page can connect to Netlify Forms or a dedicated email workflow.</p>
        </div>
      </section>
    </>
  );
}
