import Link from "next/link";
import { SearchFilter } from "@/components/search/search-filter";
import { AdSlot } from "@/components/shared/ad-slot";
import { SectionHeading } from "@/components/shared/section-heading";
import { artists, charts, countries, tracks } from "@/lib/data";
import { buildMetadata } from "@/lib/seo";

export const metadata = buildMetadata({
  title: "Global music analytics built for growth",
  description:
    "Track chart movers, artist momentum, song durability, and country-level music trends through a cleaner, more usable analytics experience.",
  path: "/"
});

export default function HomePage() {
  const searchItems = [
    ...charts.map((item) => ({ title: item.title, subtitle: `${item.platform} · ${item.market}`, href: `/charts/${item.slug}` })),
    ...artists.map((item) => ({ title: item.name, subtitle: `${item.country} · ${item.momentum}`, href: `/artists/${item.slug}` })),
    ...tracks.map((item) => ({ title: item.title, subtitle: `${item.artist} · ${item.trend}`, href: `/tracks/${item.slug}` })),
    ...countries.map((item) => ({ title: item.name, subtitle: item.insight, href: `/countries/${item.slug}` }))
  ];

  return (
    <>
      <section className="bg-white">
        <div className="mx-auto grid max-w-content gap-10 px-6 py-20 lg:grid-cols-[1.15fr_0.85fr] lg:items-center">
          <div>
            <p className="text-sm font-semibold uppercase tracking-[0.24em] text-accent">Music analytics for the global market</p>
            <h1 className="mt-5 text-5xl font-semibold tracking-tight text-ink md:text-6xl">
              A cleaner way to understand chart movement, artist growth, and track momentum.
            </h1>
            <p className="mt-6 max-w-2xl text-lg leading-8 text-slate-600">
              MusicMetrics is designed to become a global destination for music performance intelligence. It blends chart data, editorial context,
              and country-level navigation so visitors understand what is rising, what is stable, and what deserves attention next.
            </p>
            <div className="mt-8 flex flex-wrap gap-4">
              <Link href="/charts" className="rounded-xl bg-ink px-5 py-3 text-sm font-medium text-white">
                Explore charts
              </Link>
              <Link href="/insights" className="rounded-xl border border-slate-300 px-5 py-3 text-sm font-medium text-ink">
                Read insights
              </Link>
            </div>
            <div className="mt-10 grid gap-4 sm:grid-cols-3">
              <div className="rounded-2xl bg-panel p-5">
                <p className="text-3xl font-semibold text-ink">3</p>
                <p className="mt-2 text-sm text-slate-600">Core chart families ready for expansion</p>
              </div>
              <div className="rounded-2xl bg-panel p-5">
                <p className="text-3xl font-semibold text-ink">Global</p>
                <p className="mt-2 text-sm text-slate-600">Positioned for multilingual markets later</p>
              </div>
              <div className="rounded-2xl bg-panel p-5">
                <p className="text-3xl font-semibold text-ink">SEO-first</p>
                <p className="mt-2 text-sm text-slate-600">Architecture designed for durable search traffic</p>
              </div>
            </div>
          </div>
          <SearchFilter items={searchItems} />
        </div>
      </section>

      <section className="mx-auto max-w-content px-6 py-16">
        <SectionHeading
          eyebrow="Featured charts"
          title="High-signal destinations for repeat visitors"
          description="These chart modules are designed to become strong landing pages for search, internal linking, and daily revisit behavior."
        />
        <div className="mt-8 grid gap-5 lg:grid-cols-3">
          {charts.map((item) => (
            <Link key={item.slug} href={`/charts/${item.slug}`} className="rounded-3xl border border-slate-200 bg-white p-6 shadow-soft transition hover:-translate-y-0.5">
              <p className="text-sm font-semibold text-accent">{item.platform}</p>
              <h2 className="mt-3 text-xl font-semibold text-ink">{item.title}</h2>
              <p className="mt-3 text-sm leading-6 text-slate-600">{item.description}</p>
              <p className="mt-4 text-xs uppercase tracking-[0.2em] text-slate-400">{item.market} · {item.cadence}</p>
            </Link>
          ))}
        </div>
      </section>

      <section className="mx-auto grid max-w-content gap-12 px-6 py-8 lg:grid-cols-2">
        <div>
          <SectionHeading
            eyebrow="Featured artists"
            title="Artist pages with context, not just raw numbers"
            description="Each profile is built to combine performance snapshots with plain-language editorial framing."
          />
          <div className="mt-8 grid gap-4">
            {artists.map((item) => (
              <Link key={item.slug} href={`/artists/${item.slug}`} className="rounded-2xl border border-slate-200 bg-white p-5 shadow-soft">
                <div className="flex items-start justify-between gap-4">
                  <div>
                    <h3 className="text-lg font-semibold text-ink">{item.name}</h3>
                    <p className="mt-1 text-sm text-slate-500">{item.country}</p>
                  </div>
                  <p className="text-sm font-medium text-accent">{item.momentum}</p>
                </div>
                <p className="mt-4 text-sm leading-6 text-slate-600">{item.summary}</p>
              </Link>
            ))}
          </div>
        </div>
        <div>
          <SectionHeading
            eyebrow="Featured tracks"
            title="Track pages built for momentum analysis"
            description="Tracks need more than counts. They need a narrative around durability, velocity, and cross-market spread."
          />
          <div className="mt-8 grid gap-4">
            {tracks.map((item) => (
              <Link key={item.slug} href={`/tracks/${item.slug}`} className="rounded-2xl border border-slate-200 bg-white p-5 shadow-soft">
                <div className="flex items-start justify-between gap-4">
                  <div>
                    <h3 className="text-lg font-semibold text-ink">{item.title}</h3>
                    <p className="mt-1 text-sm text-slate-500">{item.artist}</p>
                  </div>
                  <p className="text-sm font-medium text-accent">{item.trend}</p>
                </div>
                <p className="mt-4 text-sm leading-6 text-slate-600">{item.summary}</p>
              </Link>
            ))}
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-content px-6 py-16">
        <SectionHeading
          eyebrow="Country trend layer"
          title="Country pages create depth, loyalty, and high-intent search reach"
          description="Local markets matter because music behavior is not uniform. Country views make the site more useful and more discoverable."
        />
        <div className="mt-8 grid gap-5 md:grid-cols-3">
          {countries.map((item) => (
            <Link key={item.slug} href={`/countries/${item.slug}`} className="rounded-3xl border border-slate-200 bg-white p-6 shadow-soft">
              <h3 className="text-xl font-semibold text-ink">{item.name}</h3>
              <p className="mt-3 text-sm leading-6 text-slate-600">{item.insight}</p>
              <p className="mt-4 text-sm text-slate-500">Top genres: {item.standoutGenres.join(", ")}</p>
            </Link>
          ))}
        </div>
      </section>

      <section className="mx-auto max-w-content px-6 py-16">
        <div className="grid gap-6 lg:grid-cols-3">
          <div className="rounded-3xl bg-white p-6 shadow-soft">
            <p className="text-sm font-semibold uppercase tracking-[0.2em] text-accent">How it works</p>
            <h3 className="mt-3 text-xl font-semibold text-ink">Static-first now, scalable later</h3>
            <p className="mt-3 text-sm leading-6 text-slate-600">The MVP is fast, crawlable, and simple to operate. Later phases can add scheduled Spotify and YouTube ingestion without rebuilding the foundation.</p>
          </div>
          <div className="rounded-3xl bg-white p-6 shadow-soft">
            <p className="text-sm font-semibold uppercase tracking-[0.2em] text-accent">Newsletter layer</p>
            <h3 className="mt-3 text-xl font-semibold text-ink">Ready for future subscriber growth</h3>
            <p className="mt-3 text-sm leading-6 text-slate-600">A future weekly digest can spotlight chart movers, breakout tracks, and country shifts without forcing user accounts into the MVP.</p>
          </div>
          <div className="rounded-3xl bg-white p-6 shadow-soft">
            <p className="text-sm font-semibold uppercase tracking-[0.2em] text-accent">Monetization fit</p>
            <h3 className="mt-3 text-xl font-semibold text-ink">Built to support ads and affiliate content</h3>
            <p className="mt-3 text-sm leading-6 text-slate-600">Display ads, editorial sponsorships, and music gear affiliate pages can live inside the structure without damaging trust.</p>
          </div>
        </div>
        <div className="mt-8 grid gap-6 lg:grid-cols-[1fr_1fr]">
          <AdSlot label="homepage banner" />
          <div className="rounded-3xl bg-ink p-8 text-white shadow-soft">
            <p className="text-sm font-semibold uppercase tracking-[0.2em] text-sky-200">Stay ahead</p>
            <h3 className="mt-3 text-2xl font-semibold">Newsletter placeholder</h3>
            <p className="mt-3 max-w-xl text-sm leading-6 text-slate-200">Future signup area for weekly chart movers, country trends, and breakout artist alerts. No backend is connected in this MVP.</p>
          </div>
        </div>
      </section>
    </>
  );
}
