import { notFound } from "next/navigation";
import { getChartBySlug, charts } from "@/lib/data";
import { buildMetadata } from "@/lib/seo";

export async function generateStaticParams() {
  return charts.map((item) => ({ slug: item.slug }));
}

export async function generateMetadata({ params }: { params: { slug: string } }) {
  const item = getChartBySlug(params.slug);
  if (!item) return {};
  return buildMetadata({ title: item.title, description: item.description, path: `/charts/${item.slug}` });
}

export default function ChartDetailPage({ params }: { params: { slug: string } }) {
  const item = getChartBySlug(params.slug);
  if (!item) notFound();

  return (
    <section className="mx-auto max-w-content px-6 py-16">
      <p className="text-sm font-semibold uppercase tracking-[0.2em] text-accent">{item.platform}</p>
      <h1 className="mt-3 text-4xl font-semibold text-ink">{item.title}</h1>
      <p className="mt-4 max-w-3xl text-lg leading-8 text-slate-600">{item.description}</p>
      <div className="mt-8 rounded-3xl border border-slate-200 bg-white p-8 shadow-soft">
        <p className="text-sm text-slate-500">Market: {item.market} · Updated: {item.updatedAt} · Cadence: {item.cadence}</p>
        <h2 className="mt-6 text-xl font-semibold text-ink">Current highlighted names</h2>
        <ul className="mt-4 grid gap-3 text-slate-600 md:grid-cols-2">
          {item.topEntries.map((entry) => (
            <li key={entry} className="rounded-2xl bg-panel p-4">{entry}</li>
          ))}
        </ul>
      </div>
    </section>
  );
}
