import Link from "next/link";
import { PageIntro } from "@/components/shared/page-intro";
import { charts } from "@/lib/data";
import { buildMetadata } from "@/lib/seo";

export const metadata = buildMetadata({
  title: "Charts",
  description: "Explore chart pages built for global, local, and cross-platform music movement.",
  path: "/charts"
});

export default function ChartsPage() {
  return (
    <>
      <PageIntro title="Charts" description="Launch-ready chart pages for global reach, country analysis, and platform-specific exploration." />
      <section className="mx-auto max-w-content px-6 py-16">
        <div className="grid gap-5 lg:grid-cols-3">
          {charts.map((item) => (
            <Link key={item.slug} href={`/charts/${item.slug}`} className="rounded-3xl border border-slate-200 bg-white p-6 shadow-soft">
              <p className="text-sm font-semibold text-accent">{item.platform}</p>
              <h2 className="mt-3 text-2xl font-semibold text-ink">{item.title}</h2>
              <p className="mt-3 text-sm leading-6 text-slate-600">{item.description}</p>
              <p className="mt-4 text-sm text-slate-500">Updated: {item.updatedAt}</p>
            </Link>
          ))}
        </div>
      </section>
    </>
  );
}
