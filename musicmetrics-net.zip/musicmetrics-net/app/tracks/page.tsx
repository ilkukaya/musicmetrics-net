import Link from "next/link";
import { PageIntro } from "@/components/shared/page-intro";
import { tracks } from "@/lib/data";
import { buildMetadata } from "@/lib/seo";

export const metadata = buildMetadata({
  title: "Tracks",
  description: "Track pages for release momentum, market spread, and editorial framing.",
  path: "/tracks"
});

export default function TracksPage() {
  return (
    <>
      <PageIntro title="Tracks" description="A future home for stream growth, view velocity, and long-tail song performance." />
      <section className="mx-auto max-w-content px-6 py-16">
        <div className="grid gap-5 md:grid-cols-2 xl:grid-cols-3">
          {tracks.map((item) => (
            <Link key={item.slug} href={`/tracks/${item.slug}`} className="rounded-3xl border border-slate-200 bg-white p-6 shadow-soft">
              <h2 className="text-2xl font-semibold text-ink">{item.title}</h2>
              <p className="mt-1 text-sm text-slate-500">{item.artist}</p>
              <p className="mt-4 text-sm font-medium text-accent">{item.trend}</p>
              <p className="mt-3 text-sm leading-6 text-slate-600">{item.summary}</p>
            </Link>
          ))}
        </div>
      </section>
    </>
  );
}
