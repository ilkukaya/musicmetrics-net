import { notFound } from "next/navigation";
import { getTrackBySlug, tracks } from "@/lib/data";
import { buildMetadata } from "@/lib/seo";

export async function generateStaticParams() {
  return tracks.map((item) => ({ slug: item.slug }));
}

export async function generateMetadata({ params }: { params: { slug: string } }) {
  const item = getTrackBySlug(params.slug);
  if (!item) return {};
  return buildMetadata({ title: item.title, description: item.summary, path: `/tracks/${item.slug}` });
}

export default function TrackDetailPage({ params }: { params: { slug: string } }) {
  const item = getTrackBySlug(params.slug);
  if (!item) notFound();

  return (
    <section className="mx-auto max-w-content px-6 py-16">
      <p className="text-sm font-semibold uppercase tracking-[0.2em] text-accent">Track profile</p>
      <h1 className="mt-3 text-4xl font-semibold text-ink">{item.title}</h1>
      <p className="mt-1 text-lg text-slate-500">{item.artist}</p>
      <p className="mt-4 max-w-3xl text-lg leading-8 text-slate-600">{item.summary}</p>
      <div className="mt-8 grid gap-5 md:grid-cols-2">
        <div className="rounded-3xl border border-slate-200 bg-white p-6 shadow-soft">
          <p className="text-sm text-slate-500">Release date</p>
          <p className="mt-2 text-2xl font-semibold text-ink">{item.releaseDate}</p>
        </div>
        <div className="rounded-3xl border border-slate-200 bg-white p-6 shadow-soft">
          <p className="text-sm text-slate-500">Trend</p>
          <p className="mt-2 text-2xl font-semibold text-ink">{item.trend}</p>
        </div>
      </div>
      <div className="mt-8 rounded-3xl border border-slate-200 bg-white p-8 shadow-soft">
        <h2 className="text-xl font-semibold text-ink">Key markets</h2>
        <ul className="mt-4 grid gap-3 text-slate-600 md:grid-cols-2">
          {item.markets.map((market) => (
            <li key={market} className="rounded-2xl bg-panel p-4">{market}</li>
          ))}
        </ul>
      </div>
    </section>
  );
}
