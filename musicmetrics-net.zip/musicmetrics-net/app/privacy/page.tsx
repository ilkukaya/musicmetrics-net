import { PageIntro } from "@/components/shared/page-intro";
import { buildMetadata } from "@/lib/seo";

export const metadata = buildMetadata({
  title: "Privacy",
  description: "Privacy placeholder for the MusicMetrics MVP.",
  path: "/privacy"
});

export default function PrivacyPage() {
  return (
    <>
      <PageIntro title="Privacy" description="Basic privacy placeholder text for the MVP release." />
      <section className="mx-auto max-w-content px-6 py-16">
        <div className="max-w-3xl rounded-3xl border border-slate-200 bg-white p-8 shadow-soft text-sm leading-7 text-slate-600">
          This MVP does not include user accounts or advanced data collection flows. When analytics, newsletter, or advertising tools are introduced, this page should be expanded with full disclosure and consent details.
        </div>
      </section>
    </>
  );
}
