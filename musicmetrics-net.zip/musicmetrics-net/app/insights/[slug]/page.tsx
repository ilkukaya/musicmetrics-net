import { notFound } from "next/navigation";
import { getInsightBySlug, insights } from "@/lib/data";
import { buildMetadata } from "@/lib/seo";

export async function generateStaticParams() {
  return insights.map((item) => ({ slug: item.slug }));
}

export async function generateMetadata({ params }: { params: { slug: string } }) {
  const item = getInsightBySlug(params.slug);
  if (!item) return {};
  return buildMetadata({ title: item.title, description: item.excerpt, path: `/insights/${item.slug}` });
}

export default function InsightDetailPage({ params }: { params: { slug: string } }) {
  const item = getInsightBySlug(params.slug);
  if (!item) notFound();

  return (
    <section className="mx-auto max-w-content px-6 py-16">
      <p className="text-sm font-semibold uppercase tracking-[0.2em] text-accent">{item.category}</p>
      <h1 className="mt-3 text-4xl font-semibold text-ink">{item.title}</h1>
      <p className="mt-4 max-w-3xl text-lg leading-8 text-slate-600">{item.excerpt}</p>
      <div className="mt-8 rounded-3xl border border-slate-200 bg-white p-8 shadow-soft">
        <ul className="grid gap-4 text-slate-600">
          {item.bullets.map((bullet) => (
            <li key={bullet} className="rounded-2xl bg-panel p-4">{bullet}</li>
          ))}
        </ul>
      </div>
    </section>
  );
}
