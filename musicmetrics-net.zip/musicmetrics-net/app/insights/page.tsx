import Link from "next/link";
import { AdSlot } from "@/components/shared/ad-slot";
import { PageIntro } from "@/components/shared/page-intro";
import { insights } from "@/lib/data";
import { buildMetadata } from "@/lib/seo";

export const metadata = buildMetadata({
  title: "Insights",
  description: "Editorial and monetization-ready content designed to work alongside a music analytics product.",
  path: "/insights"
});

export default function InsightsPage() {
  return (
    <>
      <PageIntro title="Insights" description="The editorial layer where methodology, SEO content, and future affiliate articles can coexist cleanly." />
      <section className="mx-auto max-w-content px-6 py-16">
        <div className="grid gap-8 lg:grid-cols-[1fr_320px]">
          <div className="grid gap-5">
            {insights.map((item) => (
              <Link key={item.slug} href={`/insights/${item.slug}`} className="rounded-3xl border border-slate-200 bg-white p-6 shadow-soft">
                <p className="text-sm font-semibold text-accent">{item.category}</p>
                <h2 className="mt-3 text-2xl font-semibold text-ink">{item.title}</h2>
                <p className="mt-3 text-sm leading-6 text-slate-600">{item.excerpt}</p>
                <p className="mt-4 text-sm text-slate-500">{item.readTime} · {item.publishedAt}</p>
              </Link>
            ))}
          </div>
          <div className="space-y-6">
            <AdSlot label="insights sidebar" />
            <div className="rounded-3xl bg-white p-6 shadow-soft">
              <h3 className="text-lg font-semibold text-ink">Future commercial layer</h3>
              <p className="mt-3 text-sm leading-6 text-slate-600">This sidebar can later support music gear affiliate guides, creator tools roundups, and sponsorship modules.</p>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
