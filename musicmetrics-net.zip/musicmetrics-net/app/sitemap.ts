import type { MetadataRoute } from "next";
import { siteConfig } from "@/data/site";
import { artists, charts, countries, insights, tracks } from "@/lib/data";

export default function sitemap(): MetadataRoute.Sitemap {
  const staticPages = ["", "/charts", "/artists", "/tracks", "/countries", "/insights", "/about", "/contact", "/privacy", "/terms"];
  const items = [
    ...staticPages.map((path) => ({ url: `${siteConfig.domain}${path}`, lastModified: new Date() })),
    ...charts.map((item) => ({ url: `${siteConfig.domain}/charts/${item.slug}`, lastModified: new Date(item.updatedAt) })),
    ...artists.map((item) => ({ url: `${siteConfig.domain}/artists/${item.slug}`, lastModified: new Date() })),
    ...tracks.map((item) => ({ url: `${siteConfig.domain}/tracks/${item.slug}`, lastModified: new Date() })),
    ...countries.map((item) => ({ url: `${siteConfig.domain}/countries/${item.slug}`, lastModified: new Date() })),
    ...insights.map((item) => ({ url: `${siteConfig.domain}/insights/${item.slug}`, lastModified: new Date(item.publishedAt) }))
  ];
  return items;
}
