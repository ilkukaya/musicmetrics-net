import Link from "next/link";

export default function NotFound() {
  return (
    <section className="mx-auto max-w-content px-6 py-24">
      <h1 className="text-4xl font-semibold text-ink">Page not found</h1>
      <p className="mt-4 max-w-xl text-slate-600">
        The page you requested does not exist yet. Use the main navigation to continue exploring MusicMetrics.
      </p>
      <Link href="/" className="mt-6 inline-flex rounded-xl bg-ink px-5 py-3 text-sm font-medium text-white">
        Return home
      </Link>
    </section>
  );
}
