import Link from "next/link";
import { PageIntro } from "@/components/shared/page-intro";
import { countries } from "@/lib/data";
import { buildMetadata } from "@/lib/seo";

export const metadata = buildMetadata({
  title: "Countries",
  description: "Country-level views for market-specific music behavior and discovery intent.",
  path: "/countries"
});

export default function CountriesPage() {
  return (
    <>
      <PageIntro title="Countries" description="Country pages are key for local discovery, cross-market context, and stronger organic search coverage." />
      <section className="mx-auto max-w-content px-6 py-16">
        <div className="grid gap-5 md:grid-cols-2 xl:grid-cols-3">
          {countries.map((item) => (
            <Link key={item.slug} href={`/countries/${item.slug}`} className="rounded-3xl border border-slate-200 bg-white p-6 shadow-soft">
              <h2 className="text-2xl font-semibold text-ink">{item.name}</h2>
              <p className="mt-4 text-sm leading-6 text-slate-600">{item.insight}</p>
              <p className="mt-4 text-sm text-slate-500">Leading platforms: {item.leadingPlatforms.join(", ")}</p>
            </Link>
          ))}
        </div>
      </section>
    </>
  );
}
