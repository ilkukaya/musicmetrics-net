import Link from "next/link";
import { PageIntro } from "@/components/shared/page-intro";
import { artists } from "@/lib/data";
import { buildMetadata } from "@/lib/seo";

export const metadata = buildMetadata({
  title: "Artists",
  description: "Artist pages with clean summaries, momentum framing, and future-ready data architecture.",
  path: "/artists"
});

export default function ArtistsPage() {
  return (
    <>
      <PageIntro title="Artists" description="Profiles built to eventually support richer audience, catalog, and growth narratives." />
      <section className="mx-auto max-w-content px-6 py-16">
        <div className="grid gap-5 md:grid-cols-2 xl:grid-cols-3">
          {artists.map((item) => (
            <Link key={item.slug} href={`/artists/${item.slug}`} className="rounded-3xl border border-slate-200 bg-white p-6 shadow-soft">
              <h2 className="text-2xl font-semibold text-ink">{item.name}</h2>
              <p className="mt-1 text-sm text-slate-500">{item.country}</p>
              <p className="mt-4 text-sm font-medium text-accent">{item.monthlyListeners} monthly listeners</p>
              <p className="mt-3 text-sm leading-6 text-slate-600">{item.summary}</p>
            </Link>
          ))}
        </div>
      </section>
    </>
  );
}
