import { notFound } from "next/navigation";
import { artists, getArtistBySlug } from "@/lib/data";
import { buildMetadata } from "@/lib/seo";

export async function generateStaticParams() {
  return artists.map((item) => ({ slug: item.slug }));
}

export async function generateMetadata({ params }: { params: { slug: string } }) {
  const item = getArtistBySlug(params.slug);
  if (!item) return {};
  return buildMetadata({ title: item.name, description: item.summary, path: `/artists/${item.slug}` });
}

export default function ArtistDetailPage({ params }: { params: { slug: string } }) {
  const item = getArtistBySlug(params.slug);
  if (!item) notFound();

  return (
    <section className="mx-auto max-w-content px-6 py-16">
      <p className="text-sm font-semibold uppercase tracking-[0.2em] text-accent">Artist profile</p>
      <h1 className="mt-3 text-4xl font-semibold text-ink">{item.name}</h1>
      <p className="mt-4 max-w-3xl text-lg leading-8 text-slate-600">{item.summary}</p>
      <div className="mt-8 grid gap-5 md:grid-cols-3">
        <div className="rounded-3xl border border-slate-200 bg-white p-6 shadow-soft">
          <p className="text-sm text-slate-500">Country</p>
          <p className="mt-2 text-2xl font-semibold text-ink">{item.country}</p>
        </div>
        <div className="rounded-3xl border border-slate-200 bg-white p-6 shadow-soft">
          <p className="text-sm text-slate-500">Monthly listeners</p>
          <p className="mt-2 text-2xl font-semibold text-ink">{item.monthlyListeners}</p>
        </div>
        <div className="rounded-3xl border border-slate-200 bg-white p-6 shadow-soft">
          <p className="text-sm text-slate-500">Momentum</p>
          <p className="mt-2 text-2xl font-semibold text-ink">{item.momentum}</p>
        </div>
      </div>
      <div className="mt-8 rounded-3xl border border-slate-200 bg-white p-8 shadow-soft">
        <h2 className="text-xl font-semibold text-ink">Core genres</h2>
        <p className="mt-3 text-slate-600">{item.genres.join(", ")}</p>
      </div>
    </section>
  );
}
