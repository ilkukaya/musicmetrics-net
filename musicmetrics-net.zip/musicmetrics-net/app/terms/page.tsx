import { PageIntro } from "@/components/shared/page-intro";
import { buildMetadata } from "@/lib/seo";

export const metadata = buildMetadata({
  title: "Terms",
  description: "Terms placeholder for the MusicMetrics MVP.",
  path: "/terms"
});

export default function TermsPage() {
  return (
    <>
      <PageIntro title="Terms" description="Basic terms placeholder for launch readiness." />
      <section className="mx-auto max-w-content px-6 py-16">
        <div className="max-w-3xl rounded-3xl border border-slate-200 bg-white p-8 shadow-soft text-sm leading-7 text-slate-600">
          MusicMetrics is currently presented as an informational MVP. Future production terms should clearly explain data sources, editorial disclaimers, user rights, and commercial placements.
        </div>
      </section>
    </>
  );
}
